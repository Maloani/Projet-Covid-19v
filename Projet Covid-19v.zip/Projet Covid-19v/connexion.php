﻿<?php
	if(isset($_POST['btn'])){
	//Recuperation du login et du mot de passe saisie dans le formulaire Connexion
	$login=$_POST['login'];
	$pw=$_POST['pw'];
	//Connexion a la base de donnees
		$connect=new mysqli('localhost','root','','covid');
		if($connect){
			//Lancement de la requete pour chercher le login dans la table
			$requete="SELECT * FROM agentriposte WHERE login='$login' && passe='$pw'";
			$res=$connect->query($requete);
		if ($res->num_rows > 0) {
			$ligne=$res->fetch_array();//Recuperation des elements sous forme de tableau
		session_start();
				$_SESSION['noms']=$ligne['nomComplet'];
				$_SESSION['fonction']=$ligne['fonction'];
				$_SESSION['id']=$ligne['id'];
			   if($ligne['fonction']=='ADMIN'){
						header('location:pages/admin.php');//Direction vers le menu de l'administrateur
					}else if($ligne['fonction']=='AGENTRIPOSTE'){
						header('location:pages/agent.php');
					}else{
						echo "<script type='text/javascript'>alert('Compte inconnue Incorrecte');</script>";}

				}else{
	//Si le login ou Mot de passe entres sont incorrecte un message javascript va apparaitre pour lui informer 
					echo "<script type='text/javascript'>alert('Login ou Mot de Passe Incorrecte');</script>";
	//Redirection vers la page de connexion
					echo "<meta http-equiv='refresh' content='0;URL=index.php'>";
				}
			}
		}else{
			header('location:index.php');
	}
?>