-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Lun 12 Août 2019 à 10:34
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `CARDINAL`
--
CREATE DATABASE if not EXISTS `covid`;

USE `covid`;

CREATE TABLE IF NOT EXISTS `informateur` (
  `id_info` int(11) NOT NULL AUTO_INCREMENT,
  `nomComplet` varchar(25) NULL,
  `sexe` varchar(2)  NULL,
  `adresse` varchar(25)  NULL,
  `contact` varchar(15)  NULL,
  `profession` varchar(25) NULL,
  PRIMARY KEY (`id_info`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;


CREATE TABLE IF NOT EXISTS `alerte` (
  `id_alerte` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(50)  NULL,
  `milieu` varchar(25) NULL,
  `longitude` varchar(100) NULL,
  `latittude` varchar(100) NULL,
  `detail` varchar(150) NULL,
  `id_info` int(11) NULL,
  PRIMARY KEY (`id_alerte`),
   KEY `id_info` (`id_info`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--

--

CREATE TABLE IF NOT EXISTS `agentRiposte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomComplet` varchar(150) NULL,
  `sexe` varchar(2)  NULL,
  `adresse` varchar(25) NULL,
  `telephone` varchar(15)  NULL,
  `fonction` varchar(25) NULL,
  `login` varchar(25) NULL,
  `passe` varchar(25) NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;


--

CREATE TABLE IF NOT EXISTS `intervention` (
  `id_inter` int(11) NOT NULL AUTO_INCREMENT,
  `ordre` varchar(100)  NULL,
  `dateInter` date DEFAULT NULL,
  `rapport` varchar(25) NULL,
  `id` int(11)  NULL,
  `id_alerte` int(11)  NULL,
  PRIMARY KEY (`id_inter`),
  KEY `id` (`id`),
  KEY `id_alerte` (`id_alerte`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;


--
ALTER TABLE `alerte`
  ADD CONSTRAINT `alerte_ibfk_1` FOREIGN KEY (`id_info`) REFERENCES `informateur` (`id_info`);

--
-- Contraintes pour la table `resultats`
--
ALTER TABLE `intervention`
  ADD CONSTRAINT `intervention_ibfk_1` FOREIGN KEY (`id`) REFERENCES `agentRiposte` (`id`),
  ADD CONSTRAINT `intervention_ibfk_2` FOREIGN KEY (`id_alerte`) REFERENCES `alerte` (`id_alerte`);
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
