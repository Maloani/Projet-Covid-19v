 <?php
  try{
  $bdd = new PDO('mysql:host=localhost;dbname=covid','root','');

   }catch(Exception $e){

  die('Erreur de base de donnée'.$e->getMessage());
}

    if(isset($_POST['modifier']))
    {
      $ordre=$_POST['ordre'];
     $id_alerte=$_POST['alerte'];
     $dateI =date('y-m-d');
      $query= $bdd->prepare("INSERT INTO covid.intervention(ordre,dateInter,rapport,id,id_alerte) VALUES(:ordre,:dateI,:rap,:id,:alerte");

      $query->execute(array('ordre' => $ordre,'dateI' => $dateI,'rap' =>'','id' =>1,'alerte' => $id_alerte));  
      if ($query) {
         echo'<script language="javascript">alert("l\'ordre est envoyé avec succès")</script>';
        header('Location:intervention.php');
      }else{
         echo'<script language="javascript">alert("l\'ordre non envoyé")</script>';
        header('Location:admin.php');
      }
  
    }
?>