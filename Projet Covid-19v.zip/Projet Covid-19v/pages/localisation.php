<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="X-UA-Compatible" content="IE=9"/>
  <title>Localisé le malade</title>
 
</head>
<body>
<p id="demo">Click sur le boutton pour voir localiser le malade</p>
<button onclick="getLocation()">localiser</button><br /><br />

<div id="mapholder"></div>
<script
src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script>
var x=document.getElementById("demo");
function getLocation()
  {
  if (navigator.geolocation)
    {
   
navigator.geolocation.getCurrentPosition(showPosition,showError);
    }
  else{x.innerHTML=" Geolocation n’est pas prise en charge par ce navigateur.";}
  }
function showPosition()
  {
<?php 
   if (isset($_GET['lat']) AND isset($_GET['long'])) { 


    $lat = $_GET['lat'];
    $long = $_GET['long'];

   echo ' var lat='.$lat.';';
   echo 'var  lon='.$long.';';
  }
   ?>
 
  latlon=new google.maps.LatLng(lat, lon)
  mapholder=document.getElementById('mapholder')
  mapholder.style.height='350px';
  mapholder.style.width='800px';
 
  var myOptions={
  center:latlon,zoom:14,
  mapTypeId:google.maps.MapTypeId.ROADMAP,
  mapTypeControl:false,
 
navigationControlOptions:{style:google.maps.NavigationControlStyle.SMALL}
  };
  var map=new
google.maps.Map(document.getElementById("mapholder"),myOptions);
  var marker=new
google.maps.Marker({position:latlon,map:map,title:"You are here!"});
  }
function showError(error)
  {
  switch(error.code)
    {
    case error.PERMISSION_DENIED:
      x.innerHTML="localisation non autorisé par l'utilisateur."
      break;
    case error.POSITION_UNAVAILABLE:
      x.innerHTML="L'information sur la localisation et indisponible."
      break;
    case error.TIMEOUT:
      x.innerHTML="le temps de réponce est dépasé."
      break;
    case error.UNKNOWN_ERROR:
      x.innerHTML="Une erreur inconu a été rencontrée."
      break;
    }
  }
</script>
</body>
</html>