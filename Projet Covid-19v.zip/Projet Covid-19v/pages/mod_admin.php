﻿<?php 
	session_start(); 
  $bdd = new PDO('mysql:host=localhost;dbname=CARDINAL','root','');
	if ($_SESSION['login'] == ""){
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
  }else{
  $noms  = $_SESSION['noms'];
  $login = $_SESSION['login'];
  $password = $_SESSION['pw'];

 
  
    if(isset($_POST['modifier']))
    {
        $id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?> = $_POST['id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>'];
        $noms=$_POST['noms'];
        $login=$_POST['login'];
        $password=$_POST['password'];
            
      $query= $bdd->prepare("UPDATE <?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?> SET noms = :noms, login = :login, password = :password WHERE id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?> = :id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>");

      $query->execute(array('noms' => $noms, 'login' => $login,'password' => $password, 'id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>' => $id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>));  
      if ($query) {
        
        header('Location:admin.php');
      }else{
        //echo "<div class='col-lg-12'><div class='alert alert-danger alert-dismissable'><a href='admin.php'><button type='button' style='float: right;'>&times;</button></a> <span class='glyphicon glyphicon-ok'></span> <b>Erreur lors de la modification de la classe classe reussie</b> </div></div>";
      }
  
    }

  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>DIVISION DE LA SANTE</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
	<!-- DATA TABLES -->
    <link href="../../plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
           <header class="main-header">
        <!-- Logo -->
        <a href="" class="logo"><?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="dist/img/logo.png" class="user-image" alt="User Image"/>
                  <span class="hidden-xs"></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="dist/img/logo.png" class="img-circle" alt="User Image" />
                    <p>
                      <?php echo $_SESSION['noms'];?> - <?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>
                      <small><?php 
	session_start();
Réportage Géolocalisé de Covid-19
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></small>
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <li class="user-body">
                    
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="mod_admin.php" class="btn btn-default btn-flat">Modification</a>
                    </div>
                    <div class="pull-right">
                      <a href="deconnexion.php" class="btn btn-default btn-flat">Déconnexion</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
          <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="dist/img/logo.png" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p><?php echo $_SESSION['noms'];?></p>

              <a href="#"><i class="fa fa-circle text-success"></i> Connecté</a>
            </div>
          </div>
          <!-- search form -->
         
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MENU PRINCIPAL</li>
          

            <li class="active treeview">
              <a href="#">
                <i class="fa fa-dashboard"></i> <span>Classe</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li class="active"><a href="ajout_classe.php"><i class="fa fa-circle-o"></i> Ajouter</a></li>
                <li><a href="admin.php"><i class="fa fa-circle-o"></i> Visualiser Liste</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-files-o"></i>
                <span>Elèves</span>
                
              </a>
              <ul class="treeview-menu">
                <li><a href="ajout_eleve.php"><i class="fa fa-circle-o"></i>Ajouter eleve</a></li>
                <li><a href="listeelve.php"><i class="fa fa-circle-o"></i> Liste des agents</a></li>
              </ul>
            </li>
			<li class="treeview">
              <a href="#">
                <i class="fa fa-dashboard"></i> <span>Publication</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="publication.php"><i class="fa fa-circle-o"></i>Voir publication</a></li>
                <li><a href="palm.php"><i class="fa fa-circle-o"></i> Palmarès</a></li>
              </ul>
            </li>
			
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
       <section class="content-header">
          <h1>
            EQUIPE DE RIPOSTE 
            <small><?php 
	session_start();
Réportage Géolocalisé de Covid-19
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="admin.php"><i class="fa fa-dashboard"></i> Accueil</a></li>
            <li class="active">Modification profil <?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></li>
          </ol>
        </section>


        <!-- Main content -->
        <section class="content">
          <div class="callout callout-info">
            <h4>Système de <?php 
	session_start();
Réportage Géolocalisé de Covid-19
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></h4>
            <p>Modification Profil <?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></p>
          </div>
          <!-- general form elements -->
		  <div class="row">
            <!-- left column -->
            <div class="col-md-offset-3 col-md-6">
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">MODIFICATION PROFIL</h3>
				  
                </div><!-- /.box-header -->
                <!-- form start -->
                <?php 
                  $req = $bdd->prepare("SELECT * FROM <?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?> WHERE noms = :noms AND login = :login AND password = :password");
                    $req->execute(array('noms'=>$noms,'login'=>$login,'password'=>$password));
                    $res = $req->fetch();

                ?>
                <form role="form" action="" method="post" enctype="multipart/form-data">
                  <div class="box-body">
                    
                    
                    <div class="form-group">
                      <label>Num</label>
                      <input type="hidden" class="form-control"  name="id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>"  value="<?php echo $res['id_<?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>']; ?>" required>
                    </div>
                    <div class="form-group">
                      <label>Titulaire</label>
                      <input type="text" class="form-control"  name="noms"  value="<?php echo $res['noms']; ?>" required>
                    </div>

					<div class="form-group">
                      <label>Login</label>
                      <input type="text" class="form-control" name="login" value="<?php echo $res['login']; ?>" placeholder="Tapez son Identifiant" required>
                    </div>
					<div class="form-group">
                      <label>Mot de passe</label>
                      <input type="password" class="form-control" value="<?php echo $res['password']; ?>" name="password" placeholder="Mot de Passe" required>
                    </div>
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <input type="submit" class="btn btn-primary" name="modifier" value="Modifier" >
                  </div>
                </form>
              </div><!-- /.box -->
            </div>
           </div>

        </section><!-- /.content -->
            
      </div><!-- /.content-wrapper -->
       <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>MEMOIRE L2 IG - 2020-2021</b>
        </div>
        <strong>&copy; CARDINAL</strong> .
      </footer>
    </div><!-- ./wrapper -->

    <!-- jQuery 2.1.3 -->
    <script src="plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <!-- jQuery UI 1.11.2 -->
    <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>    
    <!-- Morris.js charts -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="plugins/morris/morris.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- jQuery Knob Chart -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    <!-- daterangepicker -->
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src='plugins/fastclick/fastclick.min.js'></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js" type="text/javascript"></script>

    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
	
	<script type="text/javascript">
      $(function () {
        $("#example1").dataTable();
      });
    </script>
	<!-- DATA TABES SCRIPT -->
    <script src="../../plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="../../plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  </body>
</html>
