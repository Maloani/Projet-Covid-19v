﻿<?php 
	session_start();
	if ($_SESSION['id'] == "")
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>DIVISION DE LA SANTE</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />    
    <!-- Theme style -->
    <link href="dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- iCheck -->
    <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" />
    <!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
    <!-- jvectormap -->
    <link href="plugins/jvectormap/jquery-jvectormap-1.2.2.css" rel="stylesheet" type="text/css" />
    <!-- Date Picker -->
    <link href="plugins/datepicker/datepicker3.css" rel="stylesheet" type="text/css" />
	<!-- DATA TABLES -->
    <link href="../../plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker -->
    <link href="plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet" type="text/css" />
    <!-- bootstrap wysihtml5 - text editor -->
    <link href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css" rel="stylesheet" type="text/css" />
	
	<link href="design/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
	<link href="design/assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="skin-blue">
    <div class="wrapper">
      
      <header class="main-header">
        <!-- Logo -->
        <a href="" class="logo"><?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="dist/img/logo.png" class="user-image" alt="User Image"/>
                  <span class="hidden-xs"><?php echo $_SESSION['noms'];?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="dist/img/logo.png" class="img-circle" alt="User Image" />
                    <p>
                      <?php echo $_SESSION['noms'];?> - <?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>
                      <small><?php 
	session_start();
Réportage Géolocalisé de Covid-19
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></small>
                    </p>
                  </li>
                  <!-- Menu Body -->
                  <li class="user-body">
                    
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="mod_admin.php" class="btn btn-default btn-flat">Modification</a>
                    </div>
                    <div class="pull-right">
                      <a href="deconnexion.php" class="btn btn-default btn-flat">Déconnexion</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="dist/img/logo.png" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p><?php echo $_SESSION['noms'];?></p>

              <a href="#"><i class="fa fa-circle text-success"></i> Connecté</a>
            </div>
          </div>
          <!-- search form -->
         
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MENU PRINCIPAL</li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-dashboard"></i> <span>Classe</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li class="active"><a href="ajout_classe.php"><i class="fa fa-circle-o"></i> Ajouter</a></li>
                <li><a href="admin.php"><i class="fa fa-circle-o"></i> Visualiser Liste</a></li>
              </ul>
            </li>
            <li class="active treeview">
              <a href="#">
                <i class="fa fa-files-o"></i>
                <span>Elèves</span>
                <span class="label label-primary pull-right"><?php 
						$connect = new mysqli('localhost', 'root', '', 'CARDINAL');
						$requete = "SELECT COUNT(*) FROM eleve";
						$res = $connect->query($requete);
						$ligne=$res->fetch_row();
						$n=$ligne[0];
						echo $n;
					?></span>
              </a>
              <ul class="treeview-menu">
                <li><a href="ajout_eleve.php"><i class="fa fa-circle-o"></i>Ajouter eleve</a></li>
                <li><a href="listeelve.php"><i class="fa fa-circle-o"></i> Liste des agents</a></li>
              </ul>
            </li>
			
			
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            EQUIPE DE RIPOSTE 
            <small><?php 
	session_start();
Réportage Géolocalisé de Covid-19
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="admin.php"><i class="fa fa-dashboard"></i> Accueil</a></li>
            <li class="active">Menu Général</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
		         <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
                  <h3>
					<?php 
						$connect = new mysqli('localhost', 'root', '', 'CARDINAL');
						$requete = "SELECT COUNT(*) FROM classe";
						$res = $connect->query($requete);
						$ligne=$res->fetch_row();
						$n=$ligne[0];
						echo $n;
					?> Classes
				  </h3>
                  
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                <a href="#" class="small-box-footer">Le nbre de classes<i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>
				  <?php 
						$connect = new mysqli('localhost', 'root', '', 'CARDINAL');
						$requete = "SELECT COUNT(*) FROM classe";
						$res = $connect->query($requete);
						$ligne=$res->fetch_row();
						$n=$ligne[0];
						echo $n;
					?> Titulaires
				  <sup style="font-size: 20px"></sup></h3>
                 
                </div>
                <div class="icon">
                  <i class="ion ion-stats-bars"></i>
                </div>
                <a href="#" class="small-box-footer">Nombre des titulaires <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3>
				  <?php 
						$connect = new mysqli('localhost', 'root', '', 'CARDINAL');
						$requete = "SELECT COUNT(*) FROM eleve";
						$res = $connect->query($requete);
						$ligne=$res->fetch_row();
						$n=$ligne[0];
						echo $n;
					?> Elèves
				  </h3>
                  
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
                <a href="#" class="small-box-footer">Nombre des agents <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3>
				  <?php 
						$connect = new mysqli('localhost', 'root', '', 'CARDINAL');
						$requete = "SELECT COUNT(*) FROM <?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?>";
						$res = $connect->query($requete);
						$ligne=$res->fetch_row();
						$n=$ligne[0];
						echo $n;
					?> Préfet
				  </h3>
                 
                </div>
                <div class="icon">
                  <i class="ion ion-pie-graph"></i>
                </div>
                <a href="#" class="small-box-footer"><?php 
	session_start();
Chef de riposte
    echo "<meta http-equiv='refresh' content='0;URL=../index.php'>";
?> des études <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->
          </div><!-- /.row -->
         
          <!-- general form elements -->
		  <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">LISTE DES CLASSES</h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form role="form" action="" method="post" enctype="multipart/form-data">
                  <div class="box-body">
						
						<table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
									   <th>CLASSE</th>
									   <th>NOMS COMPLETS</th>
                                       <th>SEXE</th>
                                       <th>LIEU & DATE NAIS</th>
                                       
                                       <th></th>
                                   
                                    </thead>
                                    <tbody>
									
                                   	 <?php
								
								$cnx=mysql_connect ("localhost","root","");
								$bdd=mysql_select_db ("CARDINAL");
								mysql_query("set names UTF8");
								$req = "SELECT * FROM eleve,classe where id_cl=idclasse order by classe, nom"; 
								
								$reqt = mysql_query($req,$cnx) or die ('Erreur SQL !)<br />'.$req.'<br />'.mysql_error());
								?> 
								<?php
								while($result=mysql_fetch_array($reqt))
								{
									
								?>              

								<tr class="odd gradeX">
								<td><?php echo $result ['classe'];?><?php echo $result ['options'];?></td>
								<td><?php echo $result ['nom'];?> <?php echo $result ['postnom'];?> <?php echo $result ['prenom'];?></td>
								<td><?php echo $result ['sexe'];?></td>
								
								<td><?php echo $result ['lieunais'];?> <?php echo $result ['datenais'];?></td>
								
								<td><div class="btn-group">
                                    <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                                        Gestion
                                        <span class="caret"></span>
                                    </button>
                                    <ul class="dropdown-menu pull-right" role="menu">
										
										
										<li><?php echo" <a href= \"mod_eleve.php?id_elv=" .$result['num']."\">Modifier agent</a> \n";?>
                                        </li>
										
                                    </ul>
                                </div></td>	
								</tr>
									<?php
							}
								?>	
								</tbody>
															
						  
							<?php 
								?>	
                                    </tbody>
									
                                </table>
                  </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
           </div>

        </section><!-- /.content -->
            
      </div><!-- /.content-wrapper -->
       <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>MEMOIRE L2 IG - 2020-2021</b>
        </div>
        <strong>&copy; CARDINAL</strong> .
      </footer>
    </div><!-- ./wrapper -->
	<script src="design/plugins/jquery-1.10.2.js"></script>
    <script src="design/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="design/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="design/plugins/pace/pace.js"></script>
    <script src="design/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="design/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="design/plugins/dataTables/dataTables.bootstrap.js"></script>
    <script>
        $(document).ready(function () {
            $('#dataTables-example').dataTable();
        });
    </script>
	
	
	
	
    
  </body>
</html>