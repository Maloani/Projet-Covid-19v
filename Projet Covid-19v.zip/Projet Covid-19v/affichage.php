<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>DIVISION DE LA SANTE</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/roboto-webfont.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <!-- Sections -->
        <section id="social" class="social">
            <div class="container">
                <!-- Example row of columns -->
                <div class="row">
                    <div class="social-wrapper">
                        <div class="col-md-6">
                            <div class="social-icon">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="social-contact">
                                <a href="#"><i class="fa fa-phone"></i>+243 999 999 999</a>
                                <a href="#"><i class="fa fa-envelope"></i>contact@divisionSante.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- /containe -->       
        </section>


        <nav class="navbar navbar-default">
    <!-- fonction pour prendre les coordonnées GPS*****************************************************************--> 


<p id="demo">Click sur le boutton pour voir vos coordonées:</p>
<button onclick="getLocation()">Montrer moi</button>
 
<script>
var x=document.getElementById("demo");
function getLocation()
  {
  if (navigator.geolocation)
    {
   
navigator.geolocation.getCurrentPosition(showPosition,showError);
    }
  else{x.innerHTML="Geolocation n’est pas prise en charge par ce navigateur.";}
  }
function showPosition(position)
  {
  x.innerHTML="Latitude: " + position.coords.latitude +"<br>Longitude: " + position.coords.longitude;    
  }
function showError(error)
  {
  switch(error.code)
    {
    case error.PERMISSION_DENIED:
      x.innerHTML="localisation non autorisé par l'utilisateur."
      break;
    case error.POSITION_UNAVAILABLE:
      x.innerHTML="L'information sur la localisation et indisponible."
      break;
    case error.TIMEOUT:
      x.innerHTML="le temps de réponce est dépasé."
      break;
    case error.UNKNOWN_ERROR:
      x.innerHTML="Une erreur inconu a été rencontrée."
      break;
    }
  }
</script>

    <!-- fonction pour prendre les coordonnées GPS*****************************************************************--> 

            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <H1 style='color:green;'>DIVISION DE LA SANTE</H1>
					<b style='color:red;'>Equipe de riposte</b>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.php">Accueil</a></li>
                        <li><a href="affichage.php">Alerter</a></li>
                        <li><a href="">A propos de la DPS</a></li>
						
                        <li class="login"><a data-toggle="modal" href="#connexion">Connexion</a></li>
						
                    </ul>
					
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>

        <!--Home page style-->
        <header id="home" class="home">
            <div class="overlay-fluid-block">
                <div class="container text-center">
                       <section class="content">
          <div class="callout callout-info">
            </br> </br><b style='color:yellow; font-size:30px;'>Signaler un cas suspect</b>
          
          </div>
          <!-- general form elements -->
		  <div class="row">
            <!-- left column -->
            <div class="col-md-offset-3 col-md-6">
              <div class="box box-primary">
              <div class="box-header">
                 
			<center>
			<hr style="color:(0,150,0); box-shadow:0px 0px 5px 1px green;"><br>			
			<fieldset style="padding:3px; width:450px; border:solid 3px green;">					
							<br><br>	
		  	<form action="" method="post" >
								
			

				 <div class="form-group">
                      <label>CAS A SIGNALER</label>
                      <input type="text" class="form-control"  name="message" placeholder="cas" required>
                </div>
                 <div class="form-group">
                      <label>Milieu</label>
                      <input type="text" class="form-control"  name="milieu" placeholder="adresse" required>
                    </div>

				 <div class="form-group">
                      <label>Detail</label>
                      <input type="text" class="form-control"  name="detail" placeholder="detail" required>
                    </div>
                      <div class="form-group">
                      <label>longitude</label>
                      <input type="text" class="form-control"  name="longitude"  >
                    </div>

                       <div class="form-group">
                      <label>latitude</label>
                      <input type="text" class="form-control"  name="latitude" >
                   </div>
			
			<button class="btn btn-success" name="Afficher" style="background-color:red; color: white; height:40px; font-size:14px; width:250px; border-radius:20px;" name="Rechercher" type="submit"> envoyer </button>								
			</form>
			<br><br>
						</fieldset>
							
						
						<br/>
						<?php
		if(isset($_POST['Afficher'])){
								
			$message=$_POST['message'];
            $milieu=$_POST['milieu'];
            $detail=$_POST['detail']; 
            $longitude=$_POST['longitude'];
            $latitude=$_POST['latitude']; 

    $connect = new mysqli('localhost', 'root', '', 'covid');
    $requete = "INSERT INTO alerte(message,milieu,longitude,latittude,detail,id_info)VALUES('$message','$milieu','$longitude','$latitude','$detail',NULL)";
    $res = $connect->query($requete); 
    if($res)
        echo "<div class='col-lg-12'><div class='alert alert-success alert-dismissable'><a href='index.php'><button type='button' style='float: right;'>&times;</button></a>
                                <span class='glyphicon glyphicon-ok'></span> <b>L'alerte a été envoyé   avec succès</b> </div></div>";
                else 
                  echo "<div class='col-lg-12'><div class='alert alert-success alert-dismissable'><a href='affichage.php'><button type='button' style='float: right;'>&times;</button></a>
                <span class='glyphicon glyphicon-ok'></span> <b>erreur d'envoi</b> </div></div>";
                            }
						?>
		          <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        
        
	     
       
			 
              </div><!-- /.box -->
            </div>
           </div>

        </section>
                </div>			
            </div>
        </header>

        
  
  
        
		
		<div class="scrollup">
			<a href="#"><i class="fa fa-chevron-up"></i></a>
		</div>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/modernizr.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
	
	
     
	
</html>
