<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>DIVISION DE LA SANTE</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <!--        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css">-->


        <!--For Plugins external css-->
        <link rel="stylesheet" href="assets/css/plugins.css" />
        <link rel="stylesheet" href="assets/css/roboto-webfont.css" />

        <!--Theme custom css -->
        <link rel="stylesheet" href="assets/css/style.css">

        <!--Theme Responsive css-->
        <link rel="stylesheet" href="assets/css/responsive.css" />

        <script src="assets/js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
		<div class='preloader'><div class='loaded'>&nbsp;</div></div>
        <!-- Sections -->
        <section id="social" class="social">
            <div class="container">
                <!-- Example row of columns -->
                <div class="row">
                    <div class="social-wrapper">
                        <div class="col-md-6">
                            <div class="social-icon">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-google-plus"></i></a>
                                <a href="#"><i class="fa fa-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="social-contact">
                                <a href="#"><i class="fa fa-phone"></i>+243 999 999 999</a>
                                <a href="#"><i class="fa fa-envelope"></i>contact@divisionSante.com</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- /container -->       
        </section>

        <nav class="navbar navbar-default">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <H1 style='color:green;'>DIVISION DE LA SANTE</H1>
					<b style='color:red;'>Equipe de riposte</b>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a href="index.php">Accueil</a></li>
                        <li><a href="affichage.php">signaler un cas suspect</a></li>
                        <li><a href="">A propos de Ministere</a></li>
						
                        <li class="login"><a data-toggle="modal" href="#connexion">Connexion</a></li>
						
                    </ul>
					
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>

        <!--Home page style-->
        <header id="home" class="home">
            <div class="overlay-fluid-block">
                <div class="container text-center">
                    <div class="row">
                        <div class="home-wrapper">
                            <div class="col-md-10 col-md-offset-1">
                                <div class="home-content">

                                    <h1>Reportage Géolocalisé de covid-19</h1>
                                    <b style='color:yellow; font-size:26px;'>CARDINAL L2 IG/ISP BKV 2020-2021</b>
									
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>			
            </div>
        </header>

        
  
  
        <!--Footer-->
        <footer id="footer" class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-wrapper">

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="footer-brand">
							
                               <H1 style='color:green;'>Résultat online</H1>
                            </div>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="copyright">
                                <p>Memoire de fin d'études présenté et défendu par CARDINAL</p>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </footer>
		
		
		<div class="scrollup">
			<a href="#"><i class="fa fa-chevron-up"></i></a>
		</div>


        <script src="assets/js/vendor/jquery-1.11.2.min.js"></script>
        <script src="assets/js/vendor/bootstrap.min.js"></script>

        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/modernizr.js"></script>
        <script src="assets/js/main.js"></script>
    </body>
	
	
     <div class="modal fade" id="connexion" tabindex="-1" role="dialog" aria-labelledby="Modregister" aria-hidden="true">
    <div class="modal-dialog">
	<div class="modal-content panel-primary">
	<form role="form" method="POST" action="connexion.php" enctype="multipart/form-data">
		<div class="modal-header">
                    <button type="button" class="close btn btn-danger" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="AddSectionLabel">Connexion</h4>
                    
		</div>
		<div class="modal-body">
                   
                    <fieldset>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <tbody>
									<tr>
                                        <td><label>Login </label></td>
                                        <td colspan="3"><input type=text name="login" placeholder="Login"  class="form-control" title="Entrez le nom" data-toggle="tooltip" required /></td>
                                    </tr>
									
									 <tr>
                                        <td><label>Mot de passe </label></td>
                                        <td colspan="3"><input type="password" name="pw" placeholder="Mot de passe"  class="form-control" title="Entrez le nom" data-toggle="tooltip" required /></td>
                                    </tr>
                                   
                                </tbody>
                            </table>
                        </div>
                        <!-- /.table-responsive -->
                    </fieldset>
		</div>
		<div class="modal-footer">
                        <button type="submit" class="btn btn-success" name="btn"><i class="fa fa-send"></i> Connnexion </button>
			<button type="reset" class="btn btn-danger" data-dismiss="modal">Fermer</button>
		</div>
		</form>
		
	</div>
	<!-- /.modal-content -->
        </div>
        </div>
	
</html>
