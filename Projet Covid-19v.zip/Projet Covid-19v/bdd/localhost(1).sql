-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Ven 26 Novembre 2021 à 12:02
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `covid`
--
CREATE DATABASE `covid` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `covid`;

-- --------------------------------------------------------

--
-- Structure de la table `agentriposte`
--

CREATE TABLE IF NOT EXISTS `agentriposte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nomComplet` varchar(150) DEFAULT NULL,
  `sexe` varchar(2) DEFAULT NULL,
  `adresse` varchar(25) DEFAULT NULL,
  `telephone` varchar(15) DEFAULT NULL,
  `fonction` varchar(25) DEFAULT NULL,
  `login` varchar(25) DEFAULT NULL,
  `passe` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Contenu de la table `agentriposte`
--

INSERT INTO `agentriposte` (`id`, `nomComplet`, `sexe`, `adresse`, `telephone`, `fonction`, `login`, `passe`) VALUES
(1, 'CARDINAL', 'M', 'AV. KIBOMBO', '0985625', 'ADMIN', 'ADMIN', 'ADMIN'),
(2, 'TONON KYABILA 1', 'M', 'AV VAMARO', '0854728', 'AGENTRIPOSTE', 'tonton', 'tonton'),
(3, 'TULIZANA MUSAFIRi', 'F', 'av mwenga', '0596532', 'AGENTRIPOSTE', 'tuli', 'tuli');

-- --------------------------------------------------------

--
-- Structure de la table `alerte`
--

CREATE TABLE IF NOT EXISTS `alerte` (
  `id_alerte` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(50) DEFAULT NULL,
  `milieu` varchar(25) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `latittude` varchar(100) DEFAULT NULL,
  `detail` varchar(150) DEFAULT NULL,
  `id_info` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_alerte`),
  KEY `id_info` (`id_info`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `alerte`
--

INSERT INTO `alerte` (`id_alerte`, `message`, `milieu`, `longitude`, `latittude`, `detail`, `id_info`) VALUES
(1, 'cas suspect chez moi', 'aV Industriel', '131.044', '-25.363', 'toute la famille souffre', NULL),
(3, 'ma famille souffre', 'muhungu', '24.58569', '-2.2358947', 'depuis mardi nous somme malade', NULL),
(4, 'mon voisin souffre', 'Kibombo', '', '', 'il souffre de maux de tete et la grippe', NULL),
(5, 'nous sommes malade', 'av Muhungu', '28.848028', '-2.5123017', 'toutes la famille souffre de fievre', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `informateur`
--

CREATE TABLE IF NOT EXISTS `informateur` (
  `id_info` int(11) NOT NULL AUTO_INCREMENT,
  `nomComplet` varchar(25) DEFAULT NULL,
  `sexe` varchar(2) DEFAULT NULL,
  `adresse` varchar(25) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `profession` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id_info`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `informateur`
--

INSERT INTO `informateur` (`id_info`, `nomComplet`, `sexe`, `adresse`, `contact`, `profession`) VALUES
(1, 'shukuru birembo', 'm', 'AV VAMARO', '0258745', 'medecin');

-- --------------------------------------------------------

--
-- Structure de la table `intervention`
--

CREATE TABLE IF NOT EXISTS `intervention` (
  `id_inter` int(11) NOT NULL AUTO_INCREMENT,
  `ordre` varchar(100) DEFAULT NULL,
  `dateInter` date DEFAULT NULL,
  `rapport` varchar(25) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `id_alerte` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_inter`),
  KEY `id` (`id`),
  KEY `id_alerte` (`id_alerte`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `intervention`
--

INSERT INTO `intervention` (`id_inter`, `ordre`, `dateInter`, `rapport`, `id`, `id_alerte`) VALUES
(1, 'Recuperer le Malade', '2021-11-02', NULL, 2, 1);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `alerte`
--
ALTER TABLE `alerte`
  ADD CONSTRAINT `alerte_ibfk_1` FOREIGN KEY (`id_info`) REFERENCES `informateur` (`id_info`);

--
-- Contraintes pour la table `intervention`
--
ALTER TABLE `intervention`
  ADD CONSTRAINT `intervention_ibfk_1` FOREIGN KEY (`id`) REFERENCES `agentriposte` (`id`),
  ADD CONSTRAINT `intervention_ibfk_2` FOREIGN KEY (`id_alerte`) REFERENCES `alerte` (`id_alerte`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
