﻿<?php
	$connexion=mysql_pconnect( "localhost", "root", "" );
	mysql_select_db("CARDINAL");
?>